<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\RclientController;
use App\Http\Controllers\TestinghelperController;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\ValidIDController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::view('submit','submitdoc');
Route::post('/uploaddocs',[ClientController::class,'ClientData']);

Route::get('main', function () {
    return view('main');
});

Route::view('request','request');
Route::post('/requestform',[DocumentController::class,'DocumentData']);

Route::view('requestform','requestform');
Route::post('/submitted',[RclientController::class,'RequestclientData']);

Route::view('uploaddocs','uploaddocs');
Route::post('/track',[UploadController::class,'Upload']);



Route::get('submitted', function () {
    return view('submitted');
});

Route::get('track', function () {
    return view('track');
});

Route::get('client', function () {
    return view('client');
});

Route::get('test',[TestinghelperController::class,'index']);

Route::post('download-qr-code/{type}', 'QRController@downloadQRCode')->name('qrcode.download');