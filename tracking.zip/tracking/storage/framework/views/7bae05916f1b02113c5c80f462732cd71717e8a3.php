<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <!-- <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'> -->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'><br><br><br>
        </div><!-- end div -->

        <div align ="center">
            <h2> Your file has been submitted. </h2><br><br>
        </div><!-- end div -->
        
        <div align="center">
            <?php echo e(QrCode::size(100)->generate('HERE"S YOUR QRCODE')); ?>

            </div><!-- end div -->

        <div align ="center">
            <a href = "#"><button class="submit_button">Download QR Code</button></a>
        </div><!-- end div -->

        <div align ="center">
            <a href = "/"><button class="submit_button">Exit</button></a><br>
        </div><!-- end div -->
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\tracking\resources\views/submitted.blade.php ENDPATH**/ ?>