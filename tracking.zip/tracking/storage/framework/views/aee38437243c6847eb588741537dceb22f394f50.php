<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>
    <style>
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    </style>
    <body>
        <div align ="center">
            <!-- <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'> -->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'>
        </div><!-- end div -->

        <div align="center">
        <?php echo e(QrCode::size(100)->generate('HERE"S YOUR QRCODE')); ?>

        </div><!-- end div -->

        <div align ="center">
            <table  class="track">
                <tr class="track_record">
                  <th>Date and Time</th>
                  <th>Status</th>
                  <th>Agent</th>
                </tr>
                <tr class="track_record">
                  <td><p></p><p</p></td>
                  <td></td>
                  <td> <p></p></td>
                </tr>
                <tr class="track_record">
                  <td><p></p><p></p></td>
                  <td><p></p></td>
                  <td> <p></p></td>
                </tr>
              </table>
        </div><br><br><br><br><br><!-- end div -->

        <div align ="center" class="search_track_button">
            <a href = "/main"><button class="main_button">Another Transaction</button></a>
            <a href = "/"><button class="main_button">Done</button></a>
        </div><!-- end div -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tracking\resources\views/track.blade.php ENDPATH**/ ?>