<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <!-- <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'> -->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'>
        </div><!-- end div -->
        
        <div align ="center">
            <table class="fillout_table">
                <tr class="fillout_holder">
                    <td>
                    <form action="/submitted" method="POST">
                     <?php echo csrf_field(); ?>
                        <label for="" >Name:</label>
                    </td>
                    <td>
                        <input type="text" name="name" class="fillout_box" autocomplete="off" placeholder="Name" required>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label for="" >Address:</label>
                    </td>
                    <td>
                        <input type="text" name="address" class="fillout_box" autocomplete="off" placeholder="Address" required>
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Age:</label>
                    </td>
                    <td>
                        <input type="text" name="age" class="fillout_box" autocomplete="off"  placeholder="Age" required>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label for="" >Valid ID:</label>
                    </td>
                    <td>
                        <input type="hidden" name="primary" class="fillout_box" autocomplete="off"placeholder="Valid ID" required>
                        <select name="primary" class ="fillout_box">  
                            <option value="Select">Select</option>}  
                            <option value="student">Student ID</option>  
                            <option value="employee">Employee's ID / Office Id.</option>  
                            <option value="umid">e-Card / UMID.</option>  
                            <option value="prc">Professional Regulation Commission (PRC) ID </option>  
                            <option value="passport">Passport</option>  
                            <option value="senior">Senior Citizen ID</option>  
                            <option value="sss">SSS ID.</option>  
                            <option value="voter">Voter's ID</option>  
                            <option value="license">License ID</option>  
                        </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Date of Birth:</label>
                    </td>
                    <td>
                        <input type="date" name="birthdate" class="fillout_box" autocomplete="off"  placeholder="Date of Birth" required>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label for="" >Secondary ID:</label>
                    </td>
                    <td>
                        <input type="hidden" name="secondary" class="fillout_box" autocomplete="off" placeholder="Valid ID" required>
                        <select name="secondary" class ="fillout_box">  
                            <option value="Select">Select</option>}  
                            <option value="student">TIN ID</option>  
                            <option value="employee">Postal ID</option>  
                            <option value="umid">GSIS</option>  
                            <option value="prc">Barangay Certification </option>  
                            <option value="passport">Seaman's Book</option>  
                            <option value="senior">Highschool form 137</option>  
                            <option value="sss">DSWD</option>  
                          </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Contact Number:</label>
                    </td>
                    <td>
                        <input type="text" name="contactnumber" class="fillout_box" autocomplete="off" placeholder="Contact Number" required>
                    </td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <label for="" class="request_doc">Type of Document:</label>
                    </td>
                    <td>
                        <input type="hidden" name="document_type" class="fillout_box" autocomplete="off" required placeholder="Select Document">
                            <select name="document_type" class ="fillout_box">  
                                <option value="Select">Select Document</option>}  
                                <option value="nso">National Statistics Office</option>  
                                <option value="birthcert">Birth Certificate</option>  
                                <option value="marriagecontract">Marriage Contract</option>  
                                <option value="cedula">Cedula</option>  
                                <option value="nbi">National Bureau of Investigation</option>  
                                <option value="sss">Social Security System</option>  
                            </select>  
                    </td>
                </tr>
            </table>
        </div><!-- end div -->

            <div align ="center" class="submit_margin_button">
            <button type="submit" class="submit_button">Submit Details</button></a><br>
        </form>    
            <a href = "/main"><button class="submit_button">Previous</button></a>
            <a href = "#"><button class="submit_button">Help</button></button></a>
            </div><!-- end div -->
          
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tracking\resources\views/requestform.blade.php ENDPATH**/ ?>