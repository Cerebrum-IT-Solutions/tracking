<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'>
            <img src =" <?php echo e(URL('img/tagline.png')); ?>" class='tagline'>
        </div>

    <br><br>
    <br><br>
    <br><br>

    <div class="position" align="center">
    <div class="form-group">
            <td>
                <label class="text" for="" >Type of Document:</label>
                <input type="hidden" class="form-control"autocomplete="off" placeholder="Valid ID">
                <select class ="fillout_box">  
                    <option value="Select">Select</option>}  
                    <option value="nbi">National Bureau of Investigation</option>  
                    <option value="birth">Birth Certificate</option>  
                    <option value="marriage">Marriage Contract</option>  
                    <option value="psa">Philippine Statistics Authority</option>  
          
                </select>   
            </td>
    </div><br><br>
    <div class="fixed-position" align="center">
            <form class="text" action="upload.php" method="post" enctype="multipart/form-data">
                Upload File:
                <input type="file" class="table "name="fileToUpload" id="fileToUpload">
              </form>
    </div>
</div>
<br><br>
<br><br>
<br><br>
<br><br>
            <div align ="center">
                     <a href = "/submit"><button class="submit_button">Previous</button></a>
                    <a href = "/submitted"><button class="submit_button">Submit </button></a><br>
        </div>
</div><?php /**PATH D:\xampp\htdocs\tracking\resources\views/client.blade.php ENDPATH**/ ?>