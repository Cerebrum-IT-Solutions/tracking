<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'>
            <img src =" <?php echo e(URL('img/tagline.png')); ?>" class='tagline'><br><br><br>
        </div>
        <div>
            <table align="center">
                <td>
                    <label for="" class="request_doc">Type of Document:</label>
                    <input type="hidden" class="fillout_box" autocomplete="off" required placeholder="Select Document">
                    <select class ="fillout_box">  
                        <option value="Select">Select Document</option>}  
                        <option value="Vineet">Vineet Saini</option>  
                        <option value="Sumit">Sumit Sharma</option>  
                        <option value="Dorilal">Dorilal Agarwal</option>  
                        <option value="Omveer">Omveer Singh</option>  
                        <option value="Rohtash">Rohtash Kumar</option>  
                        <option value="Maneesh">Maneesh Tewatia</option>  
                        <option value="Priyanka">Priyanka Sachan</option>  
                        <option value="Neha">Neha Saini</option>  
                    </select>   
                </td>
            </table>
        </div>
        <div align ="center"><br><br><br><br><br><br><br>
            <a href = "/main"><button class="request_button">Previous</button></a>
            <a href = "/requestform"><button class="request_button">Next</button></a><br>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\tracking\resources\views/request.blade.php ENDPATH**/ ?>