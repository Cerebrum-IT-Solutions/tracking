<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div class="header">
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='logo'>
        </div><!-- end div -->
        
        <div align ="center">
            <a href = "/main"><button class="getstarted">Get Started</button></a>
        </div><!-- end div -->
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\tracking\resources\views/welcome.blade.php ENDPATH**/ ?>