<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'>
            <img src =" <?php echo e(URL('img/tagline.png')); ?>" class='tagline'>
        </div>
        <div align ="center">
            <table class="fillout_table">
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Name:</label>
                    </td>
                    <td>
                        <input type="text" class="fillout_box" autocomplete="off" required placeholder="Name">
                    </td>
                    <td>
                        <label for="" >Address:</label>
                    </td>
                    <td>
                        <input type="text" class="fillout_box" autocomplete="off" required placeholder="Address">
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Age:</label>
                    </td>
                    <td>
                        <input type="text" class="fillout_box" autocomplete="off" required placeholder="Age">
                    </td>
                    <td>
                        <label for="" >Valid ID:</label>
                    </td>
                    <td>
                        <input type="hidden" class="fillout_box" autocomplete="off" required placeholder="Valid ID">
                        <select class ="fillout_box">  
                            <option value="Select">Select</option>}  
                            <option value="Vineet">Vineet Saini</option>  
                            <option value="Sumit">Sumit Sharma</option>  
                            <option value="Dorilal">Dorilal Agarwal</option>  
                            <option value="Omveer">Omveer Singh</option>  
                            <option value="Rohtash">Rohtash Kumar</option>  
                            <option value="Maneesh">Maneesh Tewatia</option>  
                            <option value="Priyanka">Priyanka Sachan</option>  
                            <option value="Neha">Neha Saini</option>  
                        </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Date of Birth:</label>
                    </td>
                    <td>
                        <input type="date" class="fillout_box" autocomplete="off" required placeholder="Date of Birth">
                    </td>
                    <td>
                        <label for="" >Valid ID:</label>
                    </td>
                    <td>
                        <input type="hidden" class="fillout_box" autocomplete="off" required placeholder="Valid ID">
                        <select class ="fillout_box">  
                            <option value="Select">Select</option>}  
                            <option value="Vineet">Vineet Saini</option>  
                            <option value="Sumit">Sumit Sharma</option>  
                            <option value="Dorilal">Dorilal Agarwal</option>  
                            <option value="Omveer">Omveer Singh</option>  
                            <option value="Rohtash">Rohtash Kumar</option>  
                            <option value="Maneesh">Maneesh Tewatia</option>  
                            <option value="Priyanka">Priyanka Sachan</option>  
                            <option value="Neha">Neha Saini</option>  
                          </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Contact Number:</label>
                    </td>
                    <td>
                        <input type="text" class="fillout_box" autocomplete="off" required placeholder="Contact Number">
                    </td>
                </tr>
            </table>
        </div>
        <div align ="center">
            <a href = "/main"><button class="submit_button">Previous</button></a>
            <a href = "/client"><button class="submit_button">Submit Details</button></a><br>
            <a href = "#"><button class="submit_button">Help</button></a>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tracking\resources\views/submit.blade.php ENDPATH**/ ?>