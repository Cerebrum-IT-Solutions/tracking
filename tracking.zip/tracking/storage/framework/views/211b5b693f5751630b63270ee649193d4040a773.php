<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <!-- <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'> -->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'><br><br><br>
        </div><!-- end div -->

            <div>
                <table align="center">
                    <form action="/track" method="post" enctype="multipart/form-data">
                        <td>
                        <?php echo csrf_field(); ?>
                        <tr align="center">
                            <td><br>
                                <label for="" class="request_doc">Upload File Document:</label><br><br>
                                <input type="file" name="file"><p>NOTE: PDF, Doc or Docx File only</p>
                            </td>

                        <td>&nbsp;&nbsp;&nbsp;&nbsp;
                             <label for="" class="request_doc" >Primary ID:</label>
                            <input type="hidden" name="primaryID" class="fillout_box" autocomplete="off"placeholder="Valid ID" required>&nbsp;&nbsp;&nbsp;
                             <select name="primaryID" class ="fillout_box">  
                                    <option value="Select">Select</option>}  
                                    <option value="student">Student ID</option>  
                                    <option value="employee">Employee's ID / Office Id.</option>  
                                    <option value="umid">e-Card / UMID.</option>  
                                    <option value="prc">Professional Regulation Commission (PRC) ID </option>  
                                    <option value="passport">Passport</option>  
                                    <option value="senior">Senior Citizen ID</option>  
                                    <option value="sss">SSS ID.</option>  
                                    <option value="voter">Voter's ID</option>  
                                    <option value="license">License ID</option>  
                                </select>   
                        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="file" name="file1">
                            </td>

                            <td>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <label for="" class="request_doc" >Secondary ID:</label>
                                    <input type="hidden" name="secondaryID" class="fillout_box" autocomplete="off" placeholder="Valid ID" required>
                                    <select name="secondaryID" class ="fillout_box">  
                                        <option value="Select">Select</option>}  
                                        <option value="student">TIN ID</option>  
                                        <option value="employee">Postal ID</option>  
                                        <option value="umid">GSIS</option>  
                                        <option value="prc">Barangay Certification </option>  
                                        <option value="passport">Seaman's Book</option>  
                                        <option value="senior">Highschool form 137</option>  
                                        <option value="sss">DSWD</option>  
                                      </select>   
                                      <br><br>
                                      &nbsp;&nbsp;  <input type="file" name="file1">
                                </td>
                            </tr>
                        </tr>
                </table>
            </div><!-- end div -->
            
            <div align ="center"><br><br><br><br>
            <button type="submit" class="submit_button">Submit File</button></a><br> 
            </form>
            <a href = "/track"> <button type="submit" class="submit_button">Skip for now</button></a><br>
            <a href = "/main"><button class="request_button">Previous</button></a>
            </div> <!-- end div -->           
    </body>
</html><?php /**PATH D:\xampp\htdocs\tracking\resources\views//uploaddocs.blade.php ENDPATH**/ ?>