<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <!--<img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='logo1'>--->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'>
        </div><!-- end div -->

        <div align ="center">
            <input type="text" class="trackid" autocomplete="off" required placeholder="Please enter your tracking ID">
            <a href = "/track"><button class="search_button">Search</button></a>
        </div><!-- end div -->

        <div align ="center">
            <a href = "/submit"><button class="main_button">Submit Document</button></a><br>
            <a href = "/requestform"><button class="main_button">Request a Document</button></a><br>
            <a href = "#"><button class="main_button">Help</button></a>
        </div><!-- end div -->
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\tracking\resources\views/main.blade.php ENDPATH**/ ?>