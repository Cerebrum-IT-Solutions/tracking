<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'>
            <img src =" <?php echo e(URL('img/tagline.png')); ?>" class='tagline'>
        </div>
        <div align ="center">
        
            <table class="fillout_table">
                <tr class="fillout_holder">
                    <td>
                <form action="submit" method="POST">
                    <?php echo csrf_field(); ?>
                      <label for="" >Name:</label>
                    </td>
                    <td>
                        <input type="text" name="name" class="fillout_box" autocomplete="off" placeholder="Enter Name">
                    </td>
                    <td>
                       <label for="" >Address:</label>
                    </td>
                    <td>
                        <input type="text" name="address" class="fillout_box" autocomplete="off" placeholder="Enter Address">
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Age:</label>
                    </td>
                    <td>
                        <input type="text" name="age" class="fillout_box" autocomplete="off"  placeholder="Enter Age">
                    </td>
                    <td>
                       <label for="" >Valid ID:</label>
                    </td>
                    <td>
                        <input type="hidden" name="validID" class="fillout_box" autocomplete="off"  placeholder="Valid ID">
                        <select class ="fillout_box">  
                                <option value="Select">Select</option>}  
                                <option value="student">Student ID</option>  
                                <option value="employee">Employee's ID / Office Id.</option>  
                                <option value="umid">e-Card / UMID.</option>  
                                <option value="prc">Professional Regulation Commission (PRC) ID </option>  
                                <option value="passport">Passport</option>  
                                <option value="senior">Senior Citizen ID</option>  
                                <option value="sss">SSS ID.</option>  
                                <option value="voter">Voter's ID</option>  
                                <option value="license">License ID</option>  
    
                        </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                        <label for="" >Date of Birth:</label>
                    </td>
                    <td>
                        <input type="date" name="birthdate" class="fillout_box" autocomplete="off"  placeholder="Date of Birth">
                    </td>
                    <td>
                        <label for="">Secondary ID:</label>
                    </td>
                    <td>
                        <input type="hidden" name="secondID" class="fillout_box" autocomplete="off"  placeholder="Secondary ID">
                        <select class ="fillout_box">  
                                <option value="Select">Select</option>}  
                                <option value="student">TIN ID</option>  
                                <option value="employee">Postal ID</option>  
                                <option value="umid">GSIS</option>  
                                <option value="prc">Barangay Certification </option>  
                                <option value="passport">Seaman's Book</option>  
                                <option value="senior">Highschool form 137</option>  
                                <option value="sss">DSWD</option>
                          </select>   
                    </td>
                </tr>
                <tr class="fillout_holder">
                    <td>
                       <!-- <label for="" >Contact Number:</label>
                    </td>-->
                    <td>
                        <input type="text" name="contactnumber" class="fillout_box" autocomplete="off" required placeholder="Contact Number">
                    </td>
                </form>
                </tr>
            </table>
        </div>
        <div align ="center">
            <a href = "/main"><button class="submit_button">Previous</button></a>
            <a href = "/track"><button type="submit" class="submit_button">Submit Details</button></a><br>
            <a href = "/client"><button class="submit_button">Skip</button></a>
        </div>
    </body>
</html><?php /**PATH D:\xampp\htdocs\tracking\resources\views/submit.blade.php ENDPATH**/ ?>