<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <!-- <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'> -->
            <img src =" <?php echo e(URL('img/Systemlogo.png')); ?>" class='tagline'>
        </div><!-- end div -->

        <div align ="center">
            <table class="fillout_table">
                <tr class="fillout_holder">
                    <td>
                <form action="/uploaddocs" method="POST">
                    <?php echo csrf_field(); ?>
                      <label for="" >Name:</label>
                    </td>
                    <td>
                        <input type="text" name="name" class="fillout_box" autocomplete="off" placeholder="Enter Name" required><br>
                    </td><br><br>
                    
                    <tr class="fillout_holder">
                    <td><br>
                        <label for="" >Date of Birth:</label>
                    </td>
                    <td>
                        <input type="date" name="birthdate" class="fillout_box" autocomplete="off"  placeholder="Date of Birth" required>
                    </td>
                </tr>
            <tr class="fillout_holder">   
                    <td><br>
                       <label for="" >Address:</label>
                    </td>
                    <td><br>
                        <input type="text" name="address" class="fillout_box" autocomplete="off" placeholder="Enter Address" required>
                    </td>
                  </tr>

                   <tr class="fillout_holder">
                    <td><br>
                     <label for="" >Contact Number:</label>
                    </td>
                    <td><br>
                        <input type="text" name="contactnumber" class="fillout_box" autocomplete="off" placeholder="Contact Number" required>
                    </td>
                 
                </tr>
                <td> 

                        <label for="docu_type" class="request_doc">Type of Document:</label>
                    </td>
                    <td><br>
                        <input type="hidden" name="docu_type" class="fillout_box" autocomplete="off" placeholder="Select Document" required>
                        <select name="docu_type" class ="fillout_box">  
                            <option value="Select">Select Document</option>}  
                            <option value="nso">National Statistics Office</option>  
                            <option value="birthcert">Birth Certificate</option>  
                            <option value="marriagecontract">Marriage Contract</option>  
                            <option value="cedula">Cedula</option>  
                            <option value="nbi">National Bureau of Investigation</option>  
                            <option value="sss">Social Security System</option>  
                        </select>   
                    </td>
                </td>
                
              
            </table>
        </div><!-- end div -->

        <div align ="center" class="submit_margin_button">
            <button type="submit" class="submit_button">Next</button><br> 
            </form> 
            <a href = "/main"><button class="submit_button">Previous</button></a>
        </div><!-- end div -->
    </body>
</html><?php /**PATH C:\xampp\htdocs\tracking\resources\views/submitdoc.blade.php ENDPATH**/ ?>