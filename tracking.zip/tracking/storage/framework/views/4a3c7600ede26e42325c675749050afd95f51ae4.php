<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Document Tracking</title>

        <!-- Styles -->
        <link href="/app.css" rel="stylesheet">
        <!--Styles -->
        
    </head>

    <body>
        <div align ="center">
            <img src =" <?php echo e(URL('img/logo1.png')); ?>" class='logo1'>
            <img src =" <?php echo e(URL('img/tagline.png')); ?>" class='tagline'><br><br><br>
        </div>
            <div>
                <table align="center">
                    <form action="requestform" method="POST" enctype="multipart/form-data">
                        <td>
                        <?php echo csrf_field(); ?>
                            <label for="" class="request_doc">Type of Document:</label>
                            <input type="hidden" name="document_type" class="fillout_box" autocomplete="off" required placeholder="Select Document">
                            <select name="document_type" class ="fillout_box">  
                                <option value="Select">Select Document</option>}  
                                <option value="nso">National Statistics Office</option>  
                                <option value="birthcert">Birth Certificate</option>  
                                <option value="marriagecontract">Marriage Contract</option>  
                                <option value="cedula">Cedula</option>  
                                <option value="nbi">National Bureau of Investigation</option>  
                                <option value="sss">Social Security System</option>  
                            </select>   
                        </td>
                </table>
            </div>
                        <div align ="center"><br><br><br><br><br><br><br>
                        <button type="submit" class="request_button">Next</button></a><br>
                        <a href = "/main"><button class="request_button">Previous</button></a>
                        </div>
                     </form>  
    </body>
</html><?php /**PATH D:\xampp\htdocs\tracking\resources\views/request.blade.php ENDPATH**/ ?>