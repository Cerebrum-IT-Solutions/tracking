<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Document;

class DocumentController extends Controller
{
    function DocumentData(Request $req)
    {
        $document= new Document;
        $document->document_type=$req->document_type;
        $document->save();
       return view('requestform',compact('document'));
    }
}
