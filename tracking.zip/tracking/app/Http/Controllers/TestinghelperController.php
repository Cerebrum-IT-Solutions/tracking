<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\Helper;

class TestinghelperController extends Controller
{
    //
    function index(){
        Helper::test();
    }
}
