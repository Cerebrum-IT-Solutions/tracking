<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rclient;

class RclientController extends Controller
{
    function RequestclientData(Request $req)
    {
        $rclient= new Rclient;
        $rclient->name=$req->name;
        $rclient->address=$req->address;
        $rclient->age=$req->age;
        $rclient->primary=$req->primary; 
        $rclient->birthdate=$req->birthdate;
        $rclient->secondary=$req->secondary;
        $rclient->contactnumber=$req->contactnumber;
        $rclient->document_type=$req->document_type;
        $rclient->save();
        return view('/submitted',compact('rclient'));

    }
}
