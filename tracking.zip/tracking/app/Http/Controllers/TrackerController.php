<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\Helper;

class TrackerController extends Controller
{
    function GeneratorData(){
        return view('/track');
    }
    function save(Request $req){
        $name=$req->name;
        $tracking_ID = Helper::IDGenerator(new Tracking, 'tracking_ID', 5, 'TRD' );

        $q = new Tracking;
        $q->tracking_ID = $traking_ID;
        $q->name=$name;
        $q->save();
    }
}
