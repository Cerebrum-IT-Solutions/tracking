<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Upload;

class UploadController extends Controller
{
    //
    function Upload(Request $req){
        $req->validate([
            'file' => 'required|mimes:pdf,doc,docx,png,jpeg,jpg|max:2048']);

         $upload= new Upload();
         $upload->primaryID=$req->primaryID; 
         $upload->secondaryID=$req->secondaryID;
            if($req->file()) {
                $file = time().'_'.$req->file->getClientOriginalName();
                $file = $req->file('file')->storeAs('uploads', $file, 'public');
                $upload->file = time().'_'.$req->file->getClientOriginalName();
                $upload->file = '/storage/' . $file;
                $upload->save();
                return redirect('/track');
            }
            if($req->file()) {
                $fileone = time().'_'.$req->fileone->getClientOriginalName();
                $fileone = $req->file('file')->storeAs('ids', $fileone, 'public');
                $upload->fileone = time().'_'.$req->fileone->getClientOriginalName();
                $upload->fileone = '/storage/' . $fileone;
                $upload->save();
                return redirect('/track');
            }
            if($req->file()) {
                $filetwo = time().'_'.$req->filetwo->getClientOriginalName();
                $filetwo = $req->file('file')->storeAs('ids', $filetwo, 'public');
                $upload->filetwo = time().'_'.$req->filetwo->getClientOriginalName();
                $upload->filetwo = '/storage/' . $filetwo;
                $upload->save();
                return redirect('/track');
            }
    }

}