<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Helpers\Helper;

class ClientController extends Controller
{
    //
    function ClientData(Request $req)
    {
        $client= new Client;
        $client->name=$req->name; 
        $client->birthdate=$req->birthdate;
        $client->address=$req->address;
        $client->contactnumber=$req->contactnumber;
        $client->docu_type=$req->docu_type;
        $client->save();
        return view('/uploaddocs',compact('client'));
                
    }      
} 